import Link from "next/link";
import { site } from "@/lib/site";

export function Header() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 bg-surface-lowest/90 shadow-[0_1px_8px_rgba(0,0,0,0.04)] backdrop-blur-xl">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-6 px-6 lg:px-12">
        <Link href="/" className="flex flex-col leading-none">
          <span className="font-serif text-[22px] font-semibold tracking-tight">{site.name}</span>
          <span className="mt-1 text-[10px] font-bold uppercase tracking-[0.2em] text-ink-muted">{site.tagline}</span>
        </Link>
        <nav aria-label="Principal" className="hidden items-center gap-10 md:flex">
          {site.nav.map((l) => (
            <Link key={l.href} href={l.href} className="text-sm font-semibold tracking-wider text-ink-muted transition hover:text-violet">{l.label}</Link>
          ))}
        </nav>
        <Link href="/#cursos" className="rounded-full bg-black px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white transition hover:bg-violet">
          Ver cursos
        </Link>
      </div>
    </header>
  );
}
